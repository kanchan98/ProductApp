import sys
from bluepy.btle import Scanner, DefaultDelegate
import datetime
import requests
import json
from time import strftime
import time
import socket
import subprocess
import ConfigParser
from apscheduler.schedulers.background import BackgroundScheduler
'''--------------------------------
CONSTANTS
--------------------------------'''
CLM_TAGID=0
CLM_FIRSTSEEN=1
CLM_LASTSEEN=2
CLM_RSSI=3
CLM_BATSTAT=4
CLM_CNT=5

'''--------------------------------
Send data to server using REST API
-----------------------------------'''
def iCon():
    try:
        CNF_CONTEST_URL=CNF_API_HOST+"/home/serverstatus"
        
        #head={'content-type': 'application/json'}
        r=requests.get(CNF_CONTEST_URL,data='',headers=head)
        if r.status_code==200 and r.text=="OK":
            return True
        else:
            return False
    except BaseException as error:
        print ("An exception occured :{}".format(error))
        return False

'''--------------------------------
Send data to server using REST API
-----------------------------------'''

def SendData(ev):
    try:
        #CNF_ZONELOGS_URL=CNF_API_HOST+"/ZoneLogs/ReportZoneLogs"
        CNF_ZONELOGS_URL=CNF_API_HOST+"/ScanData/ReportScanData"
        
        print(CNF_ZONELOGS_URL)
        print(head)

        payload={}
        
        payload["Priority"]="Normal" 
        payload["Event"]= ev
        payload["TimeStamp"]=strftime('%Y-%m-%d %H:%M:%S')
        payload["Zone"]= CNF_ZONE

        tdata=[]

        for val in tagdata:
                t={}
                t["Thing"]=str(val[CLM_TAGID])
                t["RSSI"]= val[CLM_RSSI]
                t["Battery"]= val[CLM_BATSTAT]
                t["FirstSeen"]= val[CLM_FIRSTSEEN].strftime('%Y-%m-%d %H:%M:%S')
                t["LastSeen"]= val[CLM_LASTSEEN].strftime('%Y-%m-%d %H:%M:%S')
                t["ScanCount"]=val[CLM_CNT]

                tdata.append(t)
	
        payload["zoneItems"]=tdata

        #print(payload)
	ret=requests.get(CNF_ZONELOGS_URL,data=json.dumps(payload),headers=head)
		
        if ret.status_code==200: #and ret.text=="Processed":
            return True
        else:
            print(ret.text)
            return False
    except Exception as why:
        print (why)
        return False
'''--------------------------------
Send Heart beat to server using REST API
-----------------------------------'''

def SendDiscovery():
    try:
        HEARTBEAT_URL=CNF_API_HOST+"/gateways/SendDiscovery"

        payload={}
        
        payload["GatewayName"]= CNF_GWName
        payload["GatewayIP"]= MY_IP_ADDR
        payload["PlaceCode"]= CNF_ZONE
        payload["LastStatus"]= "Online"
                  
        
        ret=requests.get(HEARTBEAT_URL,data=json.dumps(payload),headers=head)
        
        if ret.status_code==200: #and ret.text=="Processed":
            return True
        else:
            return False

    except Exception as why:
        print(why)
        return False

'''---------------------------------------
FUNCTION : Searchtag
------------------------------------------'''              

def searchtag(v):
    for i,sublist in enumerate(tagdata):
        if v in sublist:
            return i
    return -1



def GetIPAddr():
    try:
        ip_addr='';
        s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        s.connect(("8.8.8.8",80))
        ip_addr=s.getsockname()[0]
        s.close()
        return ip_addr
    except Exception as error:
        print ("An exception occured in GetIPAddr:{}".format(error))
      


def ResetBT():
    print("reset bt")
    subprocess.call(['sudo','hciconfig','hci0','down'])
    time.sleep(1)
    subprocess.call(['sudo','hciconfig','hci0','up'])

def server_backhaul():
    Processing=True
    print("IN SERVER BACKHAUL")
    if SendData("REPORT")==True:
        print("Deleteing Tags")
        del tagdata[:]
    Processing=False

def heart_beat():
    print("IN HEART BEAT")
    SendDiscovery()
    

'''========================================
MAIN PROGRAM 
==========================================='''                

'''--------------------------------------------
GLOBAL VARIABLS
----------------------------------------------'''
tagdata=[]
LastReportTime=datetime.datetime.now()
LastSendDiscTime=datetime.datetime.now()
Processing=False
'''--------------------------------------------
CONFIGURATIONS - Readout from config file
----------------------------------------------'''
config=ConfigParser.ConfigParser()
config.read("/home/pi/projects/vtsgw/data/gwconfig")
#-------API--------------------
CNF_API_IP=config.get("API","IP")
CNF_API_PORT=config.get("API","Port")
CNF_API_HOST="http://"+CNF_API_IP+":"+CNF_API_PORT

#---------Scanner APP --------------
CNF_SCAN_TIME=int(config.get("SCANNER","scantime"))
#---------APP------------------------
CNF_GWName=config.get("APP","GatewayName")
CNF_ZONE=config.get("APP","zone")
CNF_BACKHAUL_INTERVAL=int(config.get("APP","backhaul_int"))
CNF_TAGS_TIMEOUT=int(config.get("APP","tags_timeout"))
CNF_WD_INTERVAL=int(config.get("APP","watchdog_int"))

head={'content-type': 'application/json'}


try:
    print ("-----------------------------------------------")
    print ("WELCOME - Niruha systems Pvt. Ltd.")
    print ("Starting Gateway......")
    print ("Starting Scanner...")
    print ("Device Time: ",str(datetime.datetime.now()))
    print ("Reading IP............")
    MY_IP_ADDR=GetIPAddr()
    print ("Device IP Addr: ",MY_IP_ADDR)
    
    scanner = Scanner() #.withDelegate(ScanDelegate())
    sched = BackgroundScheduler()
    sched.add_job(server_backhaul, 'interval', seconds=CNF_BACKHAUL_INTERVAL) # seconds can be replaced with minutes, hours, or days
    sched.add_job(heart_beat, 'interval', seconds=CNF_WD_INTERVAL) # seconds can be replaced with minutes, hours, or days
    sched.start()
    
    while True:
        
        '''---------------------------------------
        MAIN SCANNER
        ----------------------------------------'''
        try:
            devices=scanner.scan(CNF_SCAN_TIME)
        except Exception as error:
            print ("An exception occured in scan:{}".format(error))
            ResetBT()

        '''---------------------------------------
        PARSE SCANNED DATA
        ----------------------------------------'''
        for dev in devices:

            tdata=dev.getScanData()
        
            if len(tdata)==5 and tdata[2][2].find("feff")==0: #generalize this hard coded logic
            
                ln=0;tagid=0;bat=0
            
                for (adtype, desc, value) in tdata:
            
                    if adtype==255 and value.find("feff")==0:
                        bat=tdata[3][2]
                        bat=bat[-2:]
                        bat=int(bat,16)
                        if bat>100:
                            bat=100
                    
                        tagid=value[-8:]             #last 8 bytes in serial no
                        tagid=int(tagid,16)          # convert Hex to int

                        if not Processing:
                            idx=searchtag(tagid)

                            if idx==-1: #New Tag
                                tagdata.append([])
                                ln=len(tagdata)
                                ln-=1
                                                        
                                tagdata[ln].append(tagid)                   # Tagid
                                tagdata[ln].append(datetime.datetime.now()) # First Read time
                                tagdata[ln].append(datetime.datetime.now()) # Last Read Time
                                tagdata[ln].append(dev.rssi)                # RSSI
                                tagdata[ln].append(bat)                     # BATSTAT
                                tagdata[ln].append(1)                       # counter
                        
                            else: #Update Exiting tag
                                tagdata[idx][CLM_LASTSEEN]= datetime.datetime.now()
                                tagdata[idx][CLM_RSSI]=dev.rssi
                                tagdata[idx][CLM_BATSTAT]=bat
                                tagdata[idx][CLM_CNT]+=1

            
        '''---------------------------------------
        REPORT TAGS
        ----------------------------------------'''
        #if (datetime.datetime.now()-LastReportTime).total_seconds()>CNF_BACKHAUL_INTERVAL:
        #    print("Report Tags")
        #    SendData("Report")
                
        #    LastReportTime=datetime.datetime.now()
        #    print("Report Tags:Next Time:",LastReportTime.strftime('%Y-%m-%d %H:%M:%S'))
        '''---------------------------------------
        SEND DISCOVERY
        ----------------------------------------'''
        #if (datetime.datetime.now()-LastSendDiscTime).total_seconds()>CNF_WD_INTERVAL:
            #if iCon():
        #    SendDiscovery()   
        #    LastSendDiscTime=datetime.datetime.now()
        #    print("SEND DISCOVERY:Next Time",LastSendDiscTime.strftime('%Y-%m-%d %H:%M:%S'))
        '''---------------------------------------
        REMOVE OUT OF RANGE TAGS
        ----------------------------------------'''
        #n=0
        #for val in tagdata:
        #    if (datetime.datetime.now()-val[CLM_LASTSEEN]).total_seconds()>CNF_TAGS_TIMEOUT:
        #        del tagdata[n]    
        #    n+=1
        '''---------------------------------------
        DEBUG PRINT
        ----------------------------------------'''
        for val in tagdata:
            print val[0],val[1],val[2],val[3],val[4],val[5]
        print("Total Tags found: ",len(tagdata))
        print ("------------------------")
        
 
                
except BaseException as error:
    print ("An exception occured :{}".format(error))
        
    
    
        
    
   
