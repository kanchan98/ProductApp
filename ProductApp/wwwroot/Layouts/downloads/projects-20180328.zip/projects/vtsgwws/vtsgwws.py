from flask import Flask, render_template,request
import configparser
import json

app = Flask(__name__)

@app.route('/')
def index():
    return 'Hello world'
    

'''@app.route('/')
def index():
    return render_template('index.html')'''

@app.route('/api/vtsgw/getconfig', methods=['GET'])
def get_config():
    config=configparser.ConfigParser()
    config.read("/home/pi/projects/vtsgw/data/gwconfig")
    payload={}
    #-------API--------------------
    payload["IP"]=config.get("API","IP")
    payload["Port"]=config.get("API","Port")
    #---------Scanner APP --------------
    payload["scantime"]=int(config.get("SCANNER","scantime"))
#---------APP------------------------
    payload["zone"]=config.get("APP","zone")
    payload["backhaul_int"]=int(config.get("APP","backhaul_int"))
    payload["tags_timeout"]=int(config.get("APP","tags_timeout"))

    
    return json.dumps(payload)


@app.route('/vtsgw/api/v1.0/setconfig', methods=['POST'])
def set_config():
    if not request.json:
        abort(400)
    print (request.json)
    data = {'Result': True}
    return json.dumps(data)
        #stripeAmount = json_dict['stripeAmount']
       

        



    '''config=configparser.ConfigParser()
    config.read("data/gwconfig")
    payload={}
    #-------API--------------------
    payload["zonelogs"]=config.get("API","zonelogs")
    payload["activetriptags"]=config.get("API","activetriptags")
    #---------Scanner APP --------------
    payload["scantime"]=int(config.get("SCANNER","scantime"))
#---------APP------------------------
    payload["zone"]=config.get("APP","zone")
    payload["backhaul_int"]=int(config.get("APP","backhaul_int"))
    payload["tags_timeout"]=int(config.get("APP","tags_timeout"))

    
    return json.dumps(payload)'''


if __name__ == '__main__':

    app.run(debug=True, host='0.0.0.0')
