'''===============================================
FILE NAME: sql.py
AUTHOR: KETAN BHAID
DATE: 15-Sep-2017
PURPOSE: Class for Sqlite3 database operations

Niruha System Private Ltd.

================================================'''

import sqlite3
import datetime

class TagsDB:
    
    #tagrec={'id':0,'firstseen':'','lastseen':'','rssi':0,'bat':0,'readcount':'0'}
    #db=None
    #rows=None

    def __init__(self):
        self.rows=None
        self.db=None
        self.tagrec={'id':0,'firstseen':'','lastseen':'','rssi':0,'bat':0,'readcount':0}
        
    def StartDB(self):
        try:
            #self.db = sqlite3.connect(':memory:')
            self.db = sqlite3.connect("file::memory:?cache=shared")
            #self.db = sqlite3.connect('file:tagsdb?mode=memory&cache=shared')
            #cur = self.db.cursor()
            #cur.execute("CREATE TABLE tags(id INTEGER PRIMARY KEY,firstseen DATE,lastseen DATE,rssi INTEGER,bat INTEGER,readcount INTEGER)")
            #self.db.commit()
            return True
        except Exception as why:
            print(why)
            self.db.rollback()
            return False    

    def CreateTable(self):
        try:
            cur = self.db.cursor()
            cur.execute("CREATE TABLE tags(id INTEGER PRIMARY KEY,firstseen DATE,lastseen DATE,rssi INTEGER,bat INTEGER,readcount INTEGER)")
            self.db.commit()
            return True
        except Exception as why:
            print(why)
            self.db.rollback()
            return False
        
    def UpdateTag(self):
        
        try:
            cur=self.db.cursor()
            rows=cur.execute("select * from tags where id='{0}'".format(self.tagrec['id']))
    
            if len(cur.fetchall())==0:
                cur.execute("Insert into tags values('{0}','{1}','{2}','{3}','{4}','1')".format(self.tagrec['id'],self.tagrec['firstseen'],self.tagrec['lastseen'],self.tagrec['rssi'],self.tagrec['bat']))
                self.db.commit()
            else:
                cur.execute("UPDATE tags SET lastseen='{0}',rssi='{1}',bat='{2}' where id='{3}'".format(self.tagrec['lastseen'],self.tagrec['rssi'],self.tagrec['bat'],self.tagrec['id']))
                self.db.commit()
            return True
        except Exception as why:
            print(why)
            return False
        
    def GetInTags(self,tags):
        cur=self.db.cursor()
        #cur.execute('select * from tags where id in ('+','.join(map(str,tags))+') AND readcount=0') #updated logic 170320181400 continusely send intags
        cur.execute('select * from tags where id in ('+','.join(map(str,tags))+') AND readcount=1')
        rows=cur.fetchall()
        return rows

    def GetOutTags(self):
        cur=self.db.cursor()
        cur.execute("select * from tags where readcount=2")
        rows=cur.fetchall()
        return rows

    def GetStrayTags(self,tags):
        cur=self.db.cursor()
        cur.execute('select * from tags where id NOT IN ('+','.join(map(str,tags))+')')
        rows=cur.fetchall()
        return rows
    #should be called after getstraytags
    def DeleteStrayTags(self,tags):
        try:
            print("in del reg tags",tags)
            cur=self.db.cursor()
            
            cur.execute('DELETE FROM tags where id IN ('+','.join(map(str,tags))+')')
            self.db.commit()
            return True
        except Exception as why:
            print(why)
            return False
            
    def DeleteTag(self,id):
        try:
            cur=self.db.cursor()
            cur.execute("DELETE FROM tags where id='{0}'".format(id))
            self.db.commit()
            return True
        except Exception as why:
            return False
        
    def DeleteAll(self):
        try:
            cur=self.db.cursor()
            cur.execute("DELETE FROM tags")
            self.db.commit()
            return True
        except Exception as why:
            return False
        
    def DeleteTags(self):
        try:
            cur=self.db.cursor()
            cur.execute("DELETE FROM tags where readcount=2")
            self.db.commit()
            return True
        except Exception as why:
            return False


    def MarkInTags(self,tags):
        try:
            sql_query='UPDATE TAGS SET readcount=1 where id in ('+','.join(map(str,tags))+')'
            cur=self.db.cursor()
            cur.execute(sql_query)
            
            self.db.commit()
            return True
        except Exception as why:
            print(why)
            return False  
        
    def MarkOutTags(self,tmout):
        try:
            cur=self.db.cursor()
            #cur.execute("UPDATE TAGS SET readcount=2 where (strftime('%S',CURRENT_TIMESTAMP)-strftime('%S',lastseen))>={0}".format(tmout))
            #--Gudi padwa 18mar18-sqlite took GMT time by default
            #--chnaged 'now' from CURRENT_TIMESTAMP added 'localtime'
            cur.execute("UPDATE TAGS SET readcount=2 where (strftime('%s','now','localtime')-strftime('%s',lastseen))>={0}".format(tmout))
                       
            self.db.commit()
            return True
        except Exception as why:
            print(why)
            return False    
        
    def SelectAll(self):
        cur=self.db.cursor()
        cur.execute("select * from tags")
        rows=cur.fetchall()
        for row in rows:
            print(row)

    
    def Close(self):
        try:
            self.db.close()
            return True
        except Exception as why:
            print(why)
            return False   

    def TestTime(self):
        try:
            cur=self.db.cursor()
            #cur.execute("select strftime('%s',CURRENT_TIMESTAMP)-strftime('%s',lastseen) as t from tags where id=901")
            cur.execute("select strftime('%s','now','localtime')-strftime('%s',lastseen) as t,strftime('%Y-%m-%d %H:%M:%S','now','localtime'),lastseen from tags where id=901")
            rows=cur.fetchall()
            for row in rows:
                print(row)
                return True
        except Exception as why:
            print(why)
            return False    
        
    def TestUpdate(self,id,readcnt):
        try:
            sql_query="UPDATE TAGS SET readcount='{0}' where id='{1}'".format(id,readcnt)
            cur=self.db.cursor()
            cur.execute(sql_query)
            
            self.db.commit()
            return True
        except Exception as why:
            print(why)
            return False  
