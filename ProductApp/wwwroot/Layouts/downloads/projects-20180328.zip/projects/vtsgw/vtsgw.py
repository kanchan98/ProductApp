import sys
from bluepy.btle import Scanner, DefaultDelegate
import datetime
import requests
import json
from time import strftime
import time
from sql import TagsDB
import configparser
from apscheduler.schedulers.background import BackgroundScheduler
import urllib.request
import logging
import os
#import paho.mqtt.publish as publish
import socket
import subprocess

'''-------------------------------
zonelogs=http://173.212.217.104:5002/ZoneLogs/ReportZoneLogs
activetriptags=http://173.212.217.104:5002/Trips/GetActiveTripTags
connectiontest=http://173.212.217.104:5002/home/heartbeat
----------------------------------------------------'''
'''--------------------------------
CONSTANTS
--------------------------------'''
CLM_TAGID=0
CLM_FIRSTSEEN=1
CLM_LASTSEEN=2
CLM_RSSI=3
CLM_BATSTAT=4
CLM_CNT=5

'''--------------------------------
SCANNER CLASS
--------------------------------'''

class ScanDelegate(DefaultDelegate):
    def __init__(self):
        DefaultDelegate.__init__(self)


    def handleDiscovery(self, dev, isNewDev, isNewData):
        tdata=dev.getScanData()
        
        if len(tdata)==5 and tdata[2][2].find("feff")==0: #generalize this hard coded logic
            ln=0;tagid=0;bat=0
            
            for (adtype, desc, value) in tdata:
            
                if adtype==255 and value.find("feff")==0:
                    bat=tdata[3][2]
                    bat=bat[-2:]
                    bat=int(bat,16)
                    if bat>100:
                        bat=100
                    
                    tagid=value[-8:]             #last 8 hex char in serial no
                    tagid=int(tagid,16)          # convert Hex to int


                    tdb.tagrec['id']=tagid
                    tdb.tagrec['firstseen']=datetime.datetime.now()
                    tdb.tagrec['lastseen']=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    tdb.tagrec['rssi']=dev.rssi
                    tdb.tagrec['bat']=bat
                    tdb.tagrec['readcount']=1
                    tdb.UpdateTag()      
                                        
        

'''--------------------------------
GetRegTagList
-----------------------------------'''

def GetRegTagList():
    CNF_REGTAGS_URL=CNF_API_HOST+"/Trips/GetActiveTripTags"
    head={'content-type': 'application/json'}
    r=requests.get(CNF_REGTAGS_URL,data='',headers=head)
    if r.status_code==200:
        return json.loads(r.text)
    else:
        return None

'''--------------------------------
Send data to server using REST API
-----------------------------------'''

def SendData(ev,rows):
    try:
        CNF_ZONELOGS_URL=CNF_API_HOST+"/ZoneLogs/ReportZoneLogs"
        payload={}
        
        payload["Priority"]= "Normal" 
        payload["Event"]= ev
        payload["TimeStamp"]= strftime('%Y-%m-%d %H:%M:%S')
        payload["Zone"]= CNF_ZONE
                
        tdata=[]
                
        for row in rows:
            t={}
            t["Thing"]=str(row[CLM_TAGID])
            t["RSSI"]= row[CLM_RSSI]
            t["Battery"]= row[CLM_BATSTAT]
            #t["FirstSeen"]= row[CLM_FIRSTSEEN].strftime('%Y-%m-%d %H:%M:%S')
            t["FirstSeen"]= row[CLM_FIRSTSEEN]
            #t["LastSeen"]= row[CLM_LASTSEEN].strftime('%Y-%m-%d %H:%M:%S')
            t["LastSeen"]= row[CLM_LASTSEEN]
            
            tdata.append(t)

        payload["zoneItems"]=tdata

        #print(payload)

        ret=requests.get(CNF_ZONELOGS_URL,data=json.dumps(payload),headers=head)
        
        if ret.status_code==200: # and ret.text=="Processed":
            #print("In Send data: ",ret.text)
            return True
        else:
            #print(ret.text)
            return False
            

    except Exception as why:
        print(why)
        return False


'''--------------------------------
Send Heart beat to server using REST API
-----------------------------------'''

def SendDiscovery():
    try:
        HEARTBEAT_URL=CNF_API_HOST+"/gateways/SendDiscovery"
        payload={}
        
        payload["GatewayName"]= CNF_GWName
        payload["GatewayIP"]= MY_IP_ADDR
        payload["PlaceCode"]= CNF_ZONE
        payload["LastStatus"]= "Online"
                  
        
        ret=requests.get(HEARTBEAT_URL,data=json.dumps(payload),headers=head)
        
        if ret.status_code==200: #and ret.text=="Processed":
            return True
        else:
            return False

    except Exception as why:
        print(why)
        return False

'''--------------------------------
Send ERROR log to server using REST API
-----------------------------------'''

def SendErrorLog(er,mdl):
    try:
        ERRORLOG_URL=CNF_API_HOST+"/errorlogs/reporterrors"
        payload={}
        
        payload["ID"]=0
        payload["ErrorName"]= "Noname"
        payload["ErrorMsg"]= er
        payload["ErrorPriority"]= "High"
        payload["ErrorType"]= "Normal"
        payload["ErrorData"]= "None"
        payload["ErrorModule"]= str(mdl)
        payload["CreatedOn"]= strftime('%Y-%m-%d %H:%M:%S')
        payload["UpdatedOn"]= strftime('%Y-%m-%d %H:%M:%S')
                        
        
        print(payload)

        ret=requests.get(ERRORLOG_URL,data=json.dumps(payload),headers=head)
        
        if ret.status_code==200 and ret.text=="Processed":
            
            return True
        else:
            return False

    except Exception as why:
        print(why)
        return False

'''--------------------------------
SCHEDULER JOB
--------------------------------'''
def server_backhaul():
    try:
        
        db=TagsDB()
        if db.StartDB():
            db.MarkOutTags(CNF_TAGS_TIMEOUT)
            print("Tags Timeout",CNF_TAGS_TIMEOUT)

            if iCon():
                regtags=GetRegTagList()
                print("Server Backhaul:reg tag list: ",regtags)

                if len(regtags)>0:
                    intags=db.GetInTags(regtags)
                    outtags=db.GetOutTags()
                    
                    if len(intags)>0: #
                        if SendData("ZONEIN",intags):
                            #r=[row[0] for row in intags] #readout tag ids - first column
                            #db.MarkInTags(r)            # mark them as sent to server
                            print("MSG:ZONE IN SENT")
                        
                    if len(outtags)>0:
                        if SendData("ZONEOUT",outtags):
                            db.DeleteTags()
                            print("MSG:ZONE OUT SENT")
                            #print(outtags)
                else:
                    print("Error in 'GetRegTagList' API or Active Trip tags count is zero")

                
            else:
                print("No server connection")
                
        else:
            print("DB Error")
            
    except BaseException as error:
        print ("An exception occured :{}".format(error))
        SendErrorLog(error,"server backhaul")
    finally:
        db.Close()

def WatchDog():
    try:
        print("In WATCHDOG INTERVAL")
        #---Send Discovery()
        if SendDiscovery():
            print("Discovery SENT")
        else:
            print("Error in Send Discovery")

        '''-------------------------------
             STARY TAGS
           ------------------------------'''
        #---check for stray tags 20022018
        regtags=GetRegTagList()
        print("REG TAGS:",regtags)
        db=TagsDB()
        if db.StartDB():
            straytags=db.GetStrayTags(regtags)
            #print("STRAY TAGS:",straytags)
            if len(straytags)>0:
                if SendData("STRAY",straytags):
                    print("STRAY TAGS Sent")
                    r=[row[0] for row in straytags]
                    print("STRAY TAGS:",r)
                    db.DeleteStrayTags(r)
                else:
                    print("STRAY NOT SENT")
        
    except BaseException as error:
        print("An exception occured in WatchDog :{}".format(error))
        
def iCon():
    try:
        CNF_CONTEST_URL=CNF_API_HOST+"/home/serverstatus"
        
        head={'content-type': 'application/json'}
        r=requests.get(CNF_CONTEST_URL,data='',headers=head)
        if r.status_code==200 and r.text=="OK":
            return True
        else:
            return False
    except BaseException as error:
        print ("An exception occured :{}".format(error))
        return False
    
    ''' earlier function to check connection commented 01022018
    try:
        urllib.request.urlopen("http://www.google.com").close()
    except urllib.request.URLError:
        return False
    else:
        return True
        
    '''

def GetIPAddr():
    ip_addr='';
    s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    s.connect(("8.8.8.8",80))
    ip_addr=s.getsockname()[0]
    s.close()
    return ip_addr

def test():
    print("test")

def FindRegTags():
    return row
def ResetBT():
    print("reset bt")
    subprocess.call(['sudo','hciconfig','hci0','down'])
    time.sleep(1)
    subprocess.call(['sudo','hciconfig','hci0','up'])
    
         
'''==============================================================
MAIN PROGRAM 
==============================================================='''                

'''--------------------------------------------
CONFIGURATIONS - Readout from config file
----------------------------------------------'''
config=configparser.ConfigParser()
#config.read("data/gwconfig")
config.read("/home/pi/projects/vtsgw/data/gwconfig")
#-------API--------------------
CNF_API_IP=config.get("API","IP")
CNF_API_PORT=config.get("API","Port")
CNF_API_HOST="http://"+CNF_API_IP+":"+CNF_API_PORT

#---------Scanner APP --------------
CNF_SCAN_TIME=int(config.get("SCANNER","scantime"))
#---------APP------------------------
CNF_GWName=config.get("APP","GatewayName")
CNF_ZONE=config.get("APP","zone")
CNF_BACKHAUL_INTERVAL=int(config.get("APP","backhaul_int"))
CNF_TAGS_TIMEOUT=int(config.get("APP","tags_timeout"))
CNF_WD_INTERVAL=int(config.get("APP","watchdog_int"))

head={'content-type': 'application/json'}


'''--------------------------------------------
GLOBAL VARIABLS
----------------------------------------------'''
regtags=[]


try:
    print ("-----------------------------------------------")
    print ("WELCOME - Niruha systems Pvt. Ltd.")
    print ("Starting Gateway......")
    print ("Device Time: ",str(datetime.datetime.now()))
    print ("Reading IP............")
    MY_IP_ADDR=GetIPAddr()
    print ("IP Address : ",MY_IP_ADDR)
    #print ("Starting Scanner...")
        
    scanner = Scanner().withDelegate(ScanDelegate())

    print ("Starting Database....")
    tdb=TagsDB()
    if tdb.StartDB():
        tdb.CreateTable()
        print("Database Started...")
        print("Setting up DB.....")
        tdb.DeleteAll()
    else:
        print("X: Error starting database!!!")

    print("Connecting to Server.....")

    
    while True:
        if SendDiscovery():
            print("Connected to Server ",CNF_API_IP)
            break;
        else:
            print("Error connecting Server",CNF_API_IP)
            time.sleep(1)
    
    '''--------------------------------------------
    START SCHEDULER FOR BACKHAUL
    ----------------------------------------------'''
    print("Starting Scheduler......")
    sched = BackgroundScheduler()
    sched.add_job(server_backhaul, 'interval', seconds=CNF_BACKHAUL_INTERVAL) # seconds can be replaced with minutes, hours, or days
    sched.add_job(WatchDog, 'interval', seconds=CNF_WD_INTERVAL) # seconds can be replaced with minutes, hours, or days
    sched.start()
    print("Scheduler started.....")
    print("Starting Scanner.....")
                   
    while True:
        '''---------------------------------------
           MAIN SCANNER
        ----------------------------------------'''
        
        try:
            devices=scanner.scan(CNF_SCAN_TIME)
            
        except Exception as error:
            print ("An exception occured in scan:{}".format(error))
            ResetBT()
        time.sleep(1)
        '''---------------------------------------
           DEBUG PRINTING
        ----------------------------------------'''
        tdb.SelectAll()
        #tdb.TestTime()
        print("\n----------------------------------")
        #publish.single("enter", "VTSGW running", hostname="iot.eclipse.org") 
        
                
except BaseException as error:
    print ("An exception occured in Main :{}".format(error))
    #SendErrorLog(error,"Main")
finally:
    sched.shutdown()
    tdb.DeleteAll()
    tdb.Close()
    print(datetime.datetime.now())
    print ("Finaly")
      
   








        
    
   
